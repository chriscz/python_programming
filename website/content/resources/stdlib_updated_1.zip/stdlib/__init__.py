import sys
import os

# FIX issue with local imports of a module.
__base = os.path.dirname(os.path.abspath(__file__))
sys.path = [__base] + sys.path
