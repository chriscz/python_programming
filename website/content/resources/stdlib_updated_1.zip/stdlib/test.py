import stddraw
print "Hello there"
def waitMouse():
    print "waiting"
    while not stddraw.mousePressed():
        continue

while True:
    stddraw.show(0.2)
    if stddraw.hasNextKeyTyped():
        print ord(stddraw.nextKeyTyped())
